# this specific branch
this contains the creation of a function that will auto-preform the calculation of the prices

# Burger Barn
A simple, highly gernalized program for "purchaseing" burgers
does not need a readme
and yet, here we are... so why?
Hmm, what if we make a ***List of all the Reqrirments!***

# Reqrirments
just the requriments of the program. still needs work, as some of the reqriments seem in-compatabible.
## Useage & simple notes
Create a menu program that allows users to order items off a menu, and presents them with a calculated total when they are done.
Your program must include a flowchart.
## Reqrirments of Code
At start, display a one-time welcome message that will not reappear once the screen is cleared.
1. Sort the items in the List Box alphabetically
1. Have a List Box that records all items in your current order
1. Have a List Box that records all items in your current order
1. Include a Text Box that contains a running total
1. Users can only select one item in each category
1. Total is dynamically calculated as each item is entered
1. Total must include 8% sales tax
1. Users must NOT be able to modify/focus the Text Box
1. Include two Buttons: Purchase and Exit
1. Clicking Purchase displays a thank you message, then clears all fields
1. Selecting a menu item will display a message:
	1. "You purchased [menu item] for [price]"
1. If the user enters an invalid number, display an error message and ask them to enter the item again.
	- huh? what numerical input? 
1. Clear the screen after each user input
1. Clicking Purchase displays a thank you message, then clears all fields
1. Clicking Exit exits the program

## Cost of Items
 Display a menu of food options using Radio Buttons and Labels
### Burgers
1. Plain burger: $4.99
1. Cheeseburger: $5.99
1. Veggie burger: $6.49
1. Bacon Burger: $7.99
### Sides
1. Fries: $0.50
1. Tater tots: $0.75
1. Onion rings: $0.99
1. Chips: $0.99
### Drinks
1. Cola: $1.29
1. Tea: $1.19
1. Fruit Punch: $1.09
1. Water: $0.99
### Combos
1. #1 Combo: $5.99
	1. Plain Burger
	1. Fries
	1. Cola
1. #2 Combo: $6.49
	1. Cheese Burger
	1. Tea
	1. Onion Rings
1. #3 Combo: $8.99
	1. Bacon Burger
	1. Chips
	1. Cola
integrated by useing tags on the radio buttons. few alternative ideas might be used, such as utilizing the contents of the name itself. Note: combos have not been integrated
