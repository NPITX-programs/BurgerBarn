# Burger Barn
A simple general burger ordering program
#idea 1
does not need a readme, yet here we are

#idea 2
or does it?
does not need a readme, yet here we are. Or are we...