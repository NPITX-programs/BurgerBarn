﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BurgerBarn
{
    public partial class BurgerBarn : Form
    {
        public BurgerBarn()
        {
            InitializeComponent();
        }

        private void BurgerBarn_Load(object sender, EventArgs e)
        {

        }
    }
}
