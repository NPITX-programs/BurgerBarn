# Burger Barn
A simple general burger ordering program
does not need a readme

## Notes
1. this is a section with important branches. Some (like important main) are probally unescessary