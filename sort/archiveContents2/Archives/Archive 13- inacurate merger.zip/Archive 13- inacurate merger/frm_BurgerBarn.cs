﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BurgerBarn
{
    public partial class frmBurgerBarn : Form
    {
        public frmBurgerBarn()
        {
            InitializeComponent();
        }

        private void frmBurgerBarn_Load(object sender, EventArgs e)
        {

        }
    }
}
